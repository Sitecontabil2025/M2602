<?php
/**
 * System messages translation for CodeIgniter(tm)
 *
 * @author	CodeIgniter community
 * @copyright	Copyright (c) 2014-2019, British Columbia Institute of Technology (https://bcit.ca/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	https://codeigniter.com
 */
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['migration_none_found'] = 'Nenhuma migração foi encontrada.';
$lang['migration_not_found'] = 'Nenhuma migração foi encontrada com o número da versão: %s.';
$lang['migration_sequence_gap'] = 'Na sequência de migração Gap o próximo número da versão não existe.: %s.';
$lang['migration_multiple_version'] = 'Esta são as múltiplas migrações com o mesmo número de versão: %s.';
$lang['migration_class_doesnt_exist'] = 'A classe de migração "%s" não pode ser encontrada.';
$lang['migration_missing_up_method'] = 'A classe de migração "%s" está faltando o método "up".';
$lang['migration_missing_down_method'] = 'A classe de migração "%s" está faltando o método "down".';
$lang['migration_invalid_filename'] = 'A migração "%s" tem nome de arquivo inválido.';

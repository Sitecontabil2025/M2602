<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {
    public $dados = array();
    public $urlBase = 'https://sitecontabil.com.br/periodicos/json';
    public $limit = 6;

    public function __construct(){
        parent::__construct();


        $this->dados['escritorio'] = 'Escritório Contábil Modelo';
        $this->dados['titulo'] = 'Blog';
        $this->dados['descricao'] = 'Atuamos no mercado auxiliando as empresas, quanto a sua constituição, administração, consultorias e quando necessário, no encerramento das mesmas. Possuímos uma equipe de profissionais gabaritados nas áreas contábil, fiscal, trabalhista e de assessoria.';
        $this->dados['cor'] = '#FE7D00';
        $this->dados['theme'] = 'light';
        $this->dados['endereco'] = 'Rua Major Mariano';
        $this->dados['numero'] = '263';
        $this->dados['complemento'] = '';
        $this->dados['bairro'] = 'Centro';
        $this->dados['cidade'] = 'Piraju';
        $this->dados['estado'] = 'SP';
        $this->dados['cep'] = '18800-009';
        $this->dados['telefone'] = '(14) 3352-6363';
        $this->dados['whatsapp'] = '(14) 3352-6363';
        $this->dados['email'] = 'contato@ecmodelo.com.br';
        $this->dados['mapa'] = 'https://maps.app.goo.gl/bgAkCXcyWAUrCeWw8';
        $this->dados['facebook'] = '';
        $this->dados['instagram'] = '';
        $this->dados['linkedin'] = '';
        $this->dados['youtube'] = '';
        $this->dados['twitter'] = '';
        $this->dados['site'] = 'https://ecmodelo.com.br/';
    }

	public function index(){
        $this->dados['periodicos'] = get_json($this->urlBase);
		$this->load->view('blog/home', $this->dados);
	}

	public function mais(){
        $dados = $this->input->post();
        $dados['periodicos_mais'] = get_json($this->urlBase.'/'.$dados['pagina']);
		$this->load->view('blog/mais', $dados);
	}
	
    public function single($slug=null){
        $this->dados['conteudo'] = get_json($this->urlBase.'/single/'.$slug);

        if (empty($this->dados['conteudo'])):
            $this->erro404();
        else:
            $this->dados['titulo'] = $this->dados['conteudo'][0]->title;
            $this->load->view('blog/post', $this->dados);
        endif;
	}

    public function erro404(){
        $this->dados['conteudo'] = array();
        $this->dados['conteudo'][0] = (Object) array();
        $this->dados['conteudo'][0]->title = $this->dados['options']->title;
        $this->dados['conteudo'][0]->description = $this->dados['options']->description;
        $this->dados['conteudo'][0]->seo_title = $this->dados['options']->title;
        $this->dados['conteudo'][0]->seo_description = $this->dados['options']->description;
        $this->dados['conteudo'][0]->seo_keywords = $this->dados['options']->metatags;

		$this->load->view('blog/404', $this->dados);
    }
}
